#ifndef KLIENTTCPWIN_H
#define KLIENTTCPWIN_H

#include <winsock2.h>
#include <string>
#include "ObiektBaza.h"

// Klasa dziedziczy po ObiektBaza
class KlientTCPWin : public ObiektBaza 
{
    private:
    int D, kroki;
    double y_k;

    // Stworzenie socketu
    SOCKET sock;

    public:
    //Konstruktor
    KlientTCPWin(const std::string& adres_ip, int port, int D, int kroki);

    double krok_online(double u_k) override;
    void reset() override
    {
    // Brak operacji po stronie klienta; serwer resetuje zdalny obiekt po odebraniu D próbek odpowiedzi skokowej.
    };
    double get_stan() const override
    {
        return y_k;
    };

    // Destruktor
    ~KlientTCPWin() 
    {
    // Zamknięcie połączenia i czyszczenie
    if (sock != INVALID_SOCKET) {
        closesocket(sock);
    }
    WSACleanup();
    };
};

#endif